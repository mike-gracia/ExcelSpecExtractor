﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication1;
using System.Text.RegularExpressions;

namespace SpecToCalc
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            
            string inputFile = @"../../input.txt";
            string outputFile = @"../../output.txt";
            //Console.WriteLine(line);

            //clean input file (remove \n and put everything on one line
            string text = File.ReadAllText(inputFile);
            //text = Regex.Replace(text, @"[^\r]\n", "<br />");
            text = Regex.Replace(text, @"(?<!\r)\n", "<br />");
            File.WriteAllText(inputFile, text);

            string[] rowLines = File.ReadAllLines(inputFile);
            
            StreamWriter file = new StreamWriter(outputFile);

            int currentRow = 1;
            foreach (string line in rowLines)
            {
                string sanitizedLine = Regex.Replace(line, @"\t{2,}", "\t");  //remove excess tabs
                string[] lineValues = sanitizedLine.Split('\t');    //split on tabs

                if (lineValues.Length == 7 && lineValues[0] != string.Empty)
                {
                    LineData ld = new LineData(lineValues);
                    if (ld.DataType == DataType.Money)
                        file.WriteLine(Money(ld));
                }
                else
                {
                    file.WriteLine("//***********" + line + "***********\r\n", currentRow);
                }

                currentRow++;


            }
            file.Close();

        }

        public static string Money(LineData input)
        {
            string eol = Environment.NewLine;
            string toReturn;

            toReturn =
           "#region decimal " + input.FieldName + " (Line " + input.LineNumber + ")"+ eol
           + "internal Calculatable<decimal, RoundedToTheNearestInteger> " + input.InternalFieldName + ";"+ eol
           + "/// <summary> "+ eol
           + "/// " + input.Description + "  (Calculatable) "+ eol
           + "/// Reference Number " + input.ReferenceId + ""+ eol
           + "/// </summary> "+ eol
           + "[Money(AllowNegative = " + input.allowNegative + ", Precision = PrecisionType.Zero)] "+ eol
           + "[Description(\"" + input.Description + "\"), Category(\"Category\"), ReferenceNumber(\"" + input.ReferenceId + "\"), LineNumber(\"" + input.LineNumber + "\")] "+ eol
           + "public decimal " + input.FieldName + " { get { return _" + input.InternalFieldName + ".Calculate(" + input.FieldName + "_Calculation); } } "+ eol
           + "private decimal " + input.FieldName + "_Calculation() "+ eol
           + "{ "+ eol
           + "\t " + input.Calculation + ""+ eol
           + "\t //TODO: Enter code for " + input.FieldName + " calculation "+ eol
           + "} "+ eol
           + "#endregion " + input.FieldName + " "+ eol
           +  eol;

            return toReturn;

        }
    }

    public class LineData
    {
        public string FieldName = "";
        public string ReferenceId = "";
        public string LineNumber = "";
        public DataType DataType;
        public bool AllowNegative;
        public string Description = "";
        public string TaCalcNotes = "";
        public string Calculation = "";
        public string InternalFieldName = "";
        public string allowNegative = "false";
        public string precisionType = ".Zero";

        public LineData(string[] stringInput)
        {
            int i = 0;
            FieldName = stringInput[i++];
            ReferenceId = stringInput[i++];
            LineNumber = stringInput[i++];

            
                switch (stringInput[i++])
                {
                   
                    case "Money (allow negative)":
                        DataType = DataType.Money;
                        AllowNegative = true;
                        allowNegative = "true";
                        break;
                    default:
                    case "Money (non-negative)":
                        DataType = DataType.Money;
                        AllowNegative = false;
                        allowNegative = "false";
                        break;

                }

            Description = stringInput[i++];
            TaCalcNotes = stringInput[i++];
            Calculation = FormatCalculation(stringInput[i++]);
            InternalFieldName = FormatInternalFieldName(FieldName);
            precisionType = ".Zero";
        }

        private string FormatInternalFieldName(string FieldName)
        {
            return "_" + FieldName.Substring(0, 1).ToLower() + FieldName.Substring(1, FieldName.Length-1);
        }

        private string FormatCalculation(string Calculation)
        {
            return "//" + Calculation.Replace("<br />", Environment.NewLine + "// ");
        }
    }

   
}
